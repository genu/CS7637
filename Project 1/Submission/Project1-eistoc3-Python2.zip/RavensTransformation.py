class RavensTransformation:
    def __init__(self, permutation):
        self.mutations = []

        self.permutation = permutation

    def addTransformation(self, figure1, figure2):
        return -1

    def addMutation(self, mutation):
        self.mutations.append(mutation)
